/* 
    CIT Lab 5 
    Name: Catherine Nolan 
*/ 
const fastify = require("fastify")(); 

const students = [
    {
      id: 1,
      last: "Last1",
      first: "First1",
    },
    {
      id: 2,
      last: "Last2",
      first: "First2",
    },
    {
      id: 3,
      last: "Last3",
      first: "First3",
    }
  ];

//get route parameter 1
fastify.get("/cit/student", (request, reply) => {
    reply   
    .code (200)
    .header ("Content-Type", "application/json; charset=utf-8")
    .send (students);
}); 

//get route parameter 2
fastify.get("/cit/student/:id", (request, reply) => {
    const {id} = request.params; //string by default 
    let foundStudent = "Not Found"; 
    let code = 404; 
    for (let s of students) {
        if (s.id == parseInt(id)){
            foundStudent = s; 
            code = 200; 
        }
    }
    reply  
        .code (code)
        .header ("Content-Type", "application/json; charset=utf-8")
        .send (foundStudent);
});

//get route parameter 3 (*: unmatched route handler)
fastify.get("*", (request, reply) => {
    reply
        .code (404)
        .header("Content-Type", "text/html; charset=utf-8")
        .send("<h1>Unsupported request or page!</h1>");
}); 

//post route
fastify.post ("/cit/student", (request, reply) => {
  const {last, first} = request.body; 
  let maxID = students[0].id; 
  for (let s of students) {
    if (s.id > maxID)maxID = s.id;
  }
  const newStudent = {
    id: maxID + 1, 
    last: last, 
    first: first
  }; 
  students.push (newStudent);
  reply
    .code (200)
    .header ("Content-Type", "application/json; charset=utf-8")
    .send (newStudent);
});

const listenIP = "localhost";
const listenPort = 8080;
fastify.listen(listenPort, listenIP, (err, address) => {
  if (err) {
    console.log(err);
    process.exit(1);
  }
  console.log(`Server listening on ${address}`);
}); 